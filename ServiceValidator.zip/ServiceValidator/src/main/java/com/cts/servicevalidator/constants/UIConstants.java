package com.cts.servicevalidator.constants;

public class UIConstants {
	public static final String WEBROOT="D:\\root";
}
