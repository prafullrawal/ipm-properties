package com.cts.servicevalidator.service;

import java.io.File;
import java.util.List;

import com.cts.integration.dto.IJunitConstants;
import com.cts.integration.dto.TestCaseDTO;
import com.cts.servicevalidator.constants.*;
import com.cts.integration.util.ExcelUtil;

public class ServiceValidatorActionService {

	public String login() {
		
		File dir = new File(UIConstants.WEBROOT);
		
	    File[] files = dir.listFiles();
	    boolean foundUser = false;
	  //  System.setProperty("javax.net.ssl.trustStore","C:\\Program Files\\Java\\jre7\\lib\\security\\cacerts");
	    System.setProperty("javax.net.ssl.trustStore","C:\\Program Files\\Java\\jdk-11.0.3\\lib\\security\\cacerts");
	    
	    System.out.println("Trust store =>"+System.getProperty("javax.net.ssl.trustStore"));
	    try {
			for(File file:files){
				if(file.isDirectory() && file.getName().equals(this.username)){
					foundUser=true;
					String tesPlanFile=UIConstants.WEBROOT+File.separator+this.username+File.separator+IJunitConstants.DEFAULT_TEST_INPUT_EXCEL;
					File testPlan =new File(tesPlanFile);
					if(testPlan.exists()){
						testCases = ExcelUtil.readExcel(tesPlanFile);
						if(testCases.size()>0){
							
							for(int i=1;i<testCases.size();i++){
								List<String> ignoredList=testCases.get(i).getIgnoreList();
								StringBuffer sb= new StringBuffer();
								int count =0;
								for(String element:ignoredList){
									if(count==0){
										sb.append(element);
									}else{
										sb.append(",");
										sb.append(element);
									}
									count++;
								}
								ignoreFields.add(sb.toString());
							}
							
							//removing excel header
							testCases.remove(0);
						}
					}
					
					if(testCases.size()==0){
						//adding empty first row
						TestCaseDTO emptyTest = new TestCaseDTO();
						testCases.add(emptyTest);
					}
					
					System.out.println("No of test cases "+testCases.size());
					break;
				}
			}
			
			if (foundUser==true) {
				return "success";
			} else {
				addActionError(getText("error.login"));
				return "error";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}
	}
	
}
