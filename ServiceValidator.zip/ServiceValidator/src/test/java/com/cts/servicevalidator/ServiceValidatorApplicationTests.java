package com.cts.servicevalidator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
