package com.cts.servicevalidator.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceValidatorActionController {
	
	@RequestMapping("/ServiceValidatorAction/login")
	public String login() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/save")
	public String save() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/ServiceValidatorAction/add")
	public String add() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/delete")
	public String delete() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/writeXLSXFile")
	public void writeXLSXFile() {
		//return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/executeDisplay")
	public String executeDisplay() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/executeTest")
	public String executeTest() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/downloadReport")
	public String downloadReport() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/downloadReportByName")
	public String downloadReportByName() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/displayReportPage")
	public String displayReportPage() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/currentReport")
	public String currentReport() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/showInfo")
	public String showInfo() {
		return "string";
	}
	
}
