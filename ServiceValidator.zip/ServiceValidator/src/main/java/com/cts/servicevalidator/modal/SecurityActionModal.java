package com.cts.servicevalidator.modal;

import java.io.File;

public class SecurityActionModal {

	String confContent;
	String username;
	String testName;
	String targetPath;
	File certFile;
	
	public String getConfContent() {
		return confContent;
	}
	public void setConfContent(String confContent) {
		this.confContent = confContent;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	public File getCertFile() {
		return certFile;
	}
	public void setCertFile(File certFile) {
		this.certFile = certFile;
	}
}
