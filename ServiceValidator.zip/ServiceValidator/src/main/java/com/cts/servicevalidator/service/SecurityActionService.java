package com.cts.servicevalidator.service;

public class SecurityActionService {

}
